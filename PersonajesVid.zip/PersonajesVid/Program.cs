﻿using System;

class Personaje
{
    private int vida;
    private int ataque;

    public string Nombre { get; set; }
    public string Tipo { get; set; }

    public Personaje(string nombre, int vida, int ataque, string tipo)
    {
        Nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
        Tipo = tipo;
    }

    public int GetVida()
    {
        return vida;
    }

    public int GetAtaque()
    {
        return ataque;
    }

    public void RecibirDanio(int danio)
    {
        vida -= danio;
        if (vida < 0)
            vida = 0;
    }

    public virtual void Atacar(Personaje enemigo)
    {
        Console.WriteLine($"\n⚔ {Nombre} ataca a {enemigo.Nombre}");
        enemigo.RecibirDanio(ataque);
        Console.WriteLine($"{enemigo.Nombre} ahora tiene {enemigo.GetVida()} de vida.");
    }

    public void MostrarEstado()
    {
        Console.WriteLine("=================================");
        Console.WriteLine($"Nombre : {Nombre}");
        Console.WriteLine($"Tipo   : {Tipo}");
        Console.WriteLine($"Vida   : {vida}");
        Console.WriteLine($"Ataque : {ataque}");
        Console.WriteLine("=================================");
    }
}

class Guerrero : Personaje
{
    public Guerrero(string nombre, int vida, int ataque, string tipo)
        : base(nombre, vida, ataque, tipo)
    {
    }

    public override void Atacar(Personaje enemigo)
    {
        Console.WriteLine($"\n {Nombre} (Guerrero - {Tipo}) ataca con espada!");
        enemigo.RecibirDanio(GetAtaque());
        Console.WriteLine($"{enemigo.Nombre} pierde {GetAtaque()} de vida.");
        Console.WriteLine($"Vida restante de {enemigo.Nombre}: {enemigo.GetVida()}");
    }
}

class Mago : Personaje
{
    public Mago(string nombre, int vida, int ataque, string tipo)
        : base(nombre, vida, ataque, tipo)
    {
    }

    public override void Atacar(Personaje enemigo)
    {
        Console.WriteLine($"\n {Nombre} (Mago - {Tipo}) lanza un hechizo!");
        enemigo.RecibirDanio(GetAtaque());
        Console.WriteLine($"{enemigo.Nombre} pierde {GetAtaque()} de vida.");
        Console.WriteLine($"Vida restante de {enemigo.Nombre}: {enemigo.GetVida()}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Guerrero guerrero = new Guerrero("Omen", 120, 30, "Aliado");
        Mago mago = new Mago("Draco", 100, 40, "Villano");

        guerrero.MostrarEstado();
        mago.MostrarEstado();

        guerrero.Atacar(mago);
        mago.Atacar(guerrero);

        Console.WriteLine("\nEstado Final:");
        guerrero.MostrarEstado();
        mago.MostrarEstado();
    }
}

